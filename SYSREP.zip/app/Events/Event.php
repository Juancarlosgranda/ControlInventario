<?php namespace ControlInventario\Events;

abstract class Event {

	//

}
