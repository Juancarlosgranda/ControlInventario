<?php namespace ControlInventario\Commands;

abstract class Command {

	//

}
