<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use ControlInventario\Repuesto;
use ControlInventario\Sede;
use ControlInventario\Stock;

class StocksSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
        
	}

}
