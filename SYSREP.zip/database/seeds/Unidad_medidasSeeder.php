<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use ControlInventario\Unidad_medida;


class Unidad_medidasSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		
	}

}
