<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use ControlInventario\Repuesto;
use ControlInventario\Vehiculo;
use ControlInventario\Sede;
use ControlInventario\Registro_repuesto;

class Registro_repuestosSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
        
        
	}

}
