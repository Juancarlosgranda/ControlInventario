<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use ControlInventario\Categoria;

class CatesSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
       
	}

}
