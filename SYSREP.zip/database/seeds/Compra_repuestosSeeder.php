<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use ControlInventario\Repuesto;
use ControlInventario\Compra_repuesto;


class Compra_repuestosSeeder extends Seeder {

	public function run()
	{
     
		
        
	}

}
