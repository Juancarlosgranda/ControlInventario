<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

use ControlInventario\Repuesto;
use ControlInventario\Sede;
use ControlInventario\Registro_envio;

class Registro_enviosSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
        
	}

}
